const db = require("../models");

const Players = db.players;

const getPlayer = async () => {};

const getAllPlayers = async () => {};

const getFilteredPlayer = async (req, res) => {
	const allplayers = await Players.findAll({
		order: [["id", "DESC"]],
	});
	console.log("All Players:", JSON.stringify(allplayers, null, 2));
	if (allplayers) {
		res.json({ status: "success", players: allplayers });
	}
};

module.exports = {
	getPlayer,
	getAllPlayers,
	getFilteredPlayer,
};
